package pl.imsi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class Database {
	public String lookupFullname(String userid) throws SQLException {
		
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultset = null;
		String fullname = "";
		String DRIVER = "oracle.jdbc.driver.OracleDriver";
				
		//String URL = "jdbc:oracle:thin:scott/tiger@ania:1521:ania";
		String URL = "jdbc:oracle:thin:@212.51.216.168:1521:HW12";
		
		String QUERY = "SELECT FULLNAME FROM LOGIN WHERE USERID = ?";
		
		String user="PD191905";
		String password="12345";
		
		try {
			Class.forName(DRIVER);
			connection = DriverManager.getConnection(URL,user,password);
			statement = connection.prepareStatement(QUERY);
			statement.setString(1, userid);
			resultset = statement.executeQuery();
			if (resultset.next())
				fullname = resultset.getString("FULLNAME").trim();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (resultset != null)
				resultset.close();
			if (statement != null)
				statement.close();
			if (connection != null)
				connection.close();}
		return fullname;}


public String addUser(String userid, String fullname) throws SQLException {
	
	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultset = null;
	//String fullname = "";
	String DRIVER = "oracle.jdbc.driver.OracleDriver";
			
	String user="PD191905";
	String password="12345";
	//String URL = "jdbc:oracle:thin:scott/tiger@ania:1521:ania";
	String URL = "jdbc:oracle:thin:@212.51.216.168:1521:HW12";
	
	String QUERY = "INSERT INTO LOGIN(USERID, FULLNAME) VALUES(?,?)";
	
	
	
	
	try {
		Class.forName(DRIVER);
		connection = DriverManager.getConnection(URL,user,password);
		statement = connection.prepareStatement(QUERY);
		statement.setString(1, userid);
		statement.setString(2, fullname);
		int k = statement.executeUpdate();
	} catch (Exception e) {
		e.printStackTrace();
	} 
	return fullname;}}

