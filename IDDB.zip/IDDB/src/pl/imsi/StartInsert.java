package pl.imsi;

import java.sql.SQLException;

public class StartInsert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String U1 = "JJ";
		String U2 = "Jasio";
		
		try {
			String fullname = new Database().addUser(U1, U2);
			System.out.println("Fullname: "+fullname);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
