package pl.imsi;

import java.sql.SQLException;

public class Start {

	public static void main(String[] args) {
		Database database = new Database();
		
		try {
			System.out.println(database.lookupFullname("GS"));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
